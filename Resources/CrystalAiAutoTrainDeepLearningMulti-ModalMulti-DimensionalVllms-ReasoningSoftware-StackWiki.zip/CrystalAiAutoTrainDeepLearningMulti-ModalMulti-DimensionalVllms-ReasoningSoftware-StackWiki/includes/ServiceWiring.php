<?php
use MediaWiki\MediaWikiServices;

return [
	'Crystal Ai auto train deep learning multi-modal multi-dimensional vllms-reasoning software-stack wiki.Config' => static function ( MediaWikiServices $services ) {
		return $services->getService( 'ConfigFactory' )
				->makeConfig( crystal ai auto train deep learning multi-modal multi-dimensional vllms-reasoning software-stack wiki );
	},
];
