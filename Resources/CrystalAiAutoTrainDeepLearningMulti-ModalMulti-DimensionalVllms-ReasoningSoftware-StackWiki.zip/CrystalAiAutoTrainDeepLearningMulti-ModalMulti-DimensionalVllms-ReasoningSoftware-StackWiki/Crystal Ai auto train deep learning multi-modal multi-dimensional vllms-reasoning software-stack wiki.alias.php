<?php
/**
 * Aliases for Crystal Ai auto train deep learning multi-modal multi-dimensional vllms-reasoning software-stack wiki extension
 *
 * @file
 * @ingroup Extensions
 */

$specialPageAliases = [];

/** English (English) */
$specialPageAliases['en'] = [
	
];
